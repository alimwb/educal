import React, { Component } from 'react';

class SidebarBanner extends Component {

    render() {

        return (
            <div className="sidebar__widget mb-55">
                <div className="sidebar__banner w-img">
                    <img src="assets/img/blog/banner/banner-1.jpg" alt="img not found"/>
                </div>
            </div>
        );
    }
}

export default SidebarBanner;